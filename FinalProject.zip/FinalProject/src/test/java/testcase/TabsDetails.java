package testcase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.BaseTest;
import base.HomeTabs;

public class TabsDetails extends BaseTest{
	
	//To check is all tabs are available
	@Test
	public static void Availability() {
		HomeTabs hometabs = new HomeTabs(driver);
		if(hometabs.checkHome().isDisplayed()==true) {
			System.out.println("Home tab is available");
		}else {
			System.out.println("Home tab is not available");
		}
		
		if(hometabs.checkFootball().isDisplayed()==true) {
			System.out.println("Football tab is available");
		}else {
			System.out.println("Football tab is not available");
		}
		
		if(hometabs.checkBasketball().isDisplayed()==true) {
			System.out.println("Basketball tab is available");
		}else {
			System.out.println("Basketball tab is not available");
		}
		
		if(hometabs.checkCricket().isDisplayed()==true) {
			System.out.println("Cricket tab is available");
		}else {
			System.out.println("Cricket tab is not available");
		}
		
		if(hometabs.checkCybersports().isDisplayed()==true) {
			System.out.println("Cybersports tab is available");
		}else {
			System.out.println("Cybersports tab is not available");
		}
		
	}
	//To verify if url contains the tab name
	@Test
	public static void VerifyUrl() {
		HomeTabs hometabs = new HomeTabs(driver);
		System.out.println(driver.getCurrentUrl());
		hometabs.checkHome().click();
		if(driver.getCurrentUrl().contains(hometabs.checkHome().getText().toLowerCase())){
			System.out.println("URL of Home page contains the tab name");
		}else {
			System.out.println("URL of Home page does not contains the tab name");
		}
		
		hometabs.checkFootball().click();
		if(driver.getCurrentUrl().contains(hometabs.checkFootball().getText().toLowerCase())){
			System.out.println("URL of Football page contains the tab name");
		}else {
			System.out.println("URL of Football page does not contains the tab name");
		}
		
		hometabs.checkBasketball().click();
		if(driver.getCurrentUrl().contains(hometabs.checkBasketball().getText().toLowerCase())){
			System.out.println("URL of Basketball page contains the tab name");
		}else {
			System.out.println("URL of Basketball page does not contains the tab name");
		}
		
		hometabs.checkCricket().click();
		if(driver.getCurrentUrl().contains(hometabs.checkCricket().getText().toLowerCase())){
			System.out.println("URL of Cricket page contains the tab name");
		}else {
			System.out.println("URL of Cricket page does not contains the tab name");
		}
		
		hometabs.checkCybersports().click();
		if(driver.getCurrentUrl().contains(hometabs.checkCybersports().getText().toLowerCase())){
			System.out.println("URL of Cybersports page contains the tab name");
		}else {
			System.out.println("URL of Cybersports page does not contains the tab name");
		}
		
		
		
	}
	
	
	//Writing all the links in Excel sheet
	@Test
	public static void WritingExcel() throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet1 = workbook.createSheet("AllLinks");
		
		List<WebElement> link = driver.findElements(By.tagName("a"));
		for(int i= 0;i<link.size();i++) {
			Row ri = sheet1.createRow(i);
			Cell ci = ri.createCell(0);
			ci.setCellValue(link.get(i).getAttribute("href"));
		}
		
		
		File f = new File("C:\\Users\\Tnluser\\eclipse-workspace\\FinalProject\\src\\test\\resources\\data\\links.xls");
		FileOutputStream fos = new FileOutputStream(f);
		workbook.write(fos);
		workbook.close();
		
		
	}
}
