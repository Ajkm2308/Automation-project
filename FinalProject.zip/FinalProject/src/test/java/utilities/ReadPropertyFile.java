package utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertyFile {
	public static void main(String []args) throws IOException {
		//Reading properties file
		FileReader fr = new FileReader("C:\\Users\\Tnluser\\eclipse-workspace\\FinalProject\\src\\test\\resources\\configfiles\\config.properties");
		Properties pr = new Properties();
		pr.load(fr);
	}

}
