package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;


public class BaseTest {
	public static WebDriver driver;
	public static Properties prop;
	
	
	@BeforeTest
	public void setUp() throws IOException {
		prop = new Properties();
		FileInputStream ip = new FileInputStream("C:\\\\Users\\\\Tnluser\\\\eclipse-workspace\\\\FinalProject\\\\src\\\\test\\\\resources\\\\configfiles\\\\config.properties");
		prop.load(ip);
		//Setting the browser
		String browsername = prop.getProperty("browser");
		
		
		if(browsername.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browsername.equalsIgnoreCase("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		else if(browsername.equalsIgnoreCase("Edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		else {
			System.out.println("Browser not supported");
		}
		//setting the testing url
		driver.get(prop.getProperty("qaurl"));
		driver.manage().window().maximize();
		
	}
	
	@AfterTest
	public void close() {
		//Closing the browser after testing
		driver.close();
	}
	
}
