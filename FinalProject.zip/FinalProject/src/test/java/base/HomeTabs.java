package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomeTabs {
	WebDriver driver;
	//Storing the values of locators
	By home = By.xpath("//a[@href='english.html']");
	By football = By.xpath("//a[@href='football.html']");
	By basketball = By.xpath("//a[@href='busketball.html']");
	By cricket = By.xpath("//a[@href='kriket.html']");
	By cybersports = By.xpath("//a[@href='cibersport.html']");

	public HomeTabs(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement checkHome() {
		WebElement checkHome = driver.findElement(home);
		return checkHome;
	}

	public WebElement checkFootball() {
		WebElement checkFootball = driver.findElement(football);
		return checkFootball;
	}

	public WebElement checkBasketball() {
		WebElement checkBasketball = driver.findElement(basketball);
		return checkBasketball;
	}

	public WebElement checkCricket() {
		WebElement checkCricket = driver.findElement(cricket);
		return checkCricket;
	}

	public WebElement checkCybersports() {
		WebElement  checkCybersports= driver.findElement(cybersports);
		return checkCybersports;
	}
	
}
